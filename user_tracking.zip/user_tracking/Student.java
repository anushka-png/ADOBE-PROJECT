import java.util.*;  // Scanner class
import java.lang.*;
import java.io.*;
class Student
{
	public static void main(String args[])
	{
	String name;
	int roll;
	float m1,m2,total;
	Scanner s = new Scanner(System.in);
	System.out.println("Enter your name");
	name= s.next();
	System.out.println("enter roll number of a student");
	roll= s.nextInt();
	System.out.println("Enter mark1 and marks2");
	m1= s.nextFloat();
	m2= s.nextFloat();
	total= m1+m2;
	Sytem.out.println("roll =" +roll);
	System.out.println("Name= " + name);
	System.out.println("Marks 1 =" + m1);
	System.out.println("Marks 2 =" + m2);
	System.out.println("Total =" +total);
	
	}
}